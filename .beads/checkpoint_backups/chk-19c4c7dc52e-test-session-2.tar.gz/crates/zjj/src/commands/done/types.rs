//! Types for done command
//!
//! This module provides zero-panic, type-safe types for completing work in a workspace.

use std::fmt;

use serde::{Deserialize, Serialize};
use zjj_core::OutputFormat;

use super::conflict::ConflictDetectionResult;

/// CLI arguments for done command (parsed in main.rs)
#[derive(Debug, Clone)]
#[expect(clippy::struct_excessive_bools)] // CLI flags: >3 bools is appropriate for independent options
pub struct DoneArgs {
    /// Workspace to complete
    pub workspace: Option<String>,

    /// Commit message (auto-generated if not provided)
    pub message: Option<String>,

    /// Keep workspace after merge
    pub keep_workspace: bool,

    /// Skip workspace retention (cleanup immediately)
    pub no_keep: bool,

    /// Squash all commits into one
    pub squash: bool,

    /// Preview without executing
    pub dry_run: bool,

    /// Detect conflicts before merging
    pub detect_conflicts: bool,

    /// Skip bead status update
    pub no_bead_update: bool,

    /// Output format
    pub format: OutputFormat,
}

impl DoneArgs {
    /// Convert to `DoneOptions`
    pub fn to_options(&self) -> DoneOptions {
        DoneOptions {
            workspace: self.workspace.clone(),
            message: self.message.clone(),
            keep_workspace: self.keep_workspace,
            no_keep: self.no_keep,
            squash: self.squash,
            dry_run: self.dry_run,
            detect_conflicts: self.detect_conflicts,
            no_bead_update: self.no_bead_update,
            format: self.format,
        }
    }
}

/// Internal options for done command
#[derive(Debug, Clone)]
#[expect(clippy::struct_excessive_bools)]
pub struct DoneOptions {
    pub workspace: Option<String>,
    pub message: Option<String>,
    pub keep_workspace: bool,
    pub no_keep: bool,
    pub squash: bool,
    pub dry_run: bool,
    pub detect_conflicts: bool,
    pub no_bead_update: bool,
    pub format: OutputFormat,
}

/// Output from done command
#[derive(Debug, Clone, Default, Serialize, Deserialize)]
#[expect(clippy::struct_excessive_bools)]
pub struct DoneOutput {
    pub workspace_name: String,
    pub bead_id: Option<String>,
    pub files_committed: usize,
    pub commits_merged: usize,
    pub merged: bool,
    pub cleaned: bool,
    pub bead_closed: bool,
    pub session_updated: bool,
    /// New status of the session after done command (if updated)
    pub new_status: Option<String>,
    pub pushed_to_remote: bool,
    pub dry_run: bool,
    pub preview: Option<DonePreview>,
    pub error: Option<String>,
}

/// Undo entry for history log
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct UndoEntry {
    pub session_name: String,
    pub commit_id: String,
    pub pre_merge_commit_id: String,
    pub timestamp: u64,
    pub pushed_to_remote: bool,
    pub status: String,
}

/// Preview information for dry-run mode
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DonePreview {
    pub uncommitted_files: Vec<String>,
    pub commits_to_merge: Vec<CommitInfo>,
    pub potential_conflicts: Vec<String>,
    pub bead_to_close: Option<String>,
    pub workspace_path: String,
    /// Detailed conflict detection result (when --detect-conflicts is used)
    pub conflict_detection: Option<ConflictDetectionResult>,
}

/// Information about a commit
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CommitInfo {
    pub change_id: String,
    pub commit_id: String,
    pub description: String,
    pub timestamp: String,
}

/// Done operation error (zero-panic, no unwraps)
#[derive(Debug, Clone)]
pub enum DoneError {
    NotInWorkspace {
        current_location: String,
    },
    NotAJjRepo,
    #[allow(dead_code)] // Reserved for future workspace validation
    WorkspaceNotFound {
        workspace_name: String,
    },
    CommitFailed {
        reason: String,
    },
    MergeConflict {
        conflicts: Vec<String>,
    },
    MergeFailed {
        reason: String,
    },
    CleanupFailed {
        reason: String,
    },
    BeadUpdateFailed {
        reason: String,
    },
    JjCommandFailed {
        command: String,
        reason: String,
    },
    InvalidState {
        reason: String,
    },
}

impl fmt::Display for DoneError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::NotInWorkspace { current_location } => write!(
                f,
                "Not in a workspace (currently at: {current_location}). Use 'zjj focus <name>' to switch to a workspace first."
            ),
            Self::NotAJjRepo => write!(f, "Not in a JJ repository. Run 'zjj init' first."),
            Self::WorkspaceNotFound { workspace_name } => {
                write!(f, "Workspace '{workspace_name}' not found")
            }
            Self::CommitFailed { reason } => write!(f, "Failed to commit changes: {reason}"),
            Self::MergeConflict { conflicts } => {
                write!(f, "Merge conflicts detected: {}", conflicts.join(", "))
            }
            Self::MergeFailed { reason } => write!(f, "Failed to merge to main: {reason}"),
            Self::CleanupFailed { reason } => write!(f, "Failed to cleanup workspace: {reason}"),
            Self::BeadUpdateFailed { reason } => {
                write!(f, "Failed to update bead status: {reason}")
            }
            Self::JjCommandFailed { command, reason } => {
                write!(f, "JJ command '{command}' failed: {reason}")
            }
            Self::InvalidState { reason } => write!(f, "Invalid state: {reason}"),
        }
    }
}

impl std::error::Error for DoneError {}

/// Error conversions from trait abstractions
impl From<crate::commands::done::executor::ExecutorError> for DoneError {
    fn from(err: crate::commands::done::executor::ExecutorError) -> Self {
        Self::JjCommandFailed {
            command: "jj".to_string(),
            reason: err.to_string(),
        }
    }
}

impl From<crate::commands::done::bead::BeadError> for DoneError {
    fn from(err: crate::commands::done::bead::BeadError) -> Self {
        Self::BeadUpdateFailed {
            reason: err.to_string(),
        }
    }
}

impl From<crate::commands::done::filesystem::FsError> for DoneError {
    fn from(err: crate::commands::done::filesystem::FsError) -> Self {
        Self::InvalidState {
            reason: err.to_string(),
        }
    }
}

impl DoneError {
    #[allow(dead_code)]
    pub const fn error_code(&self) -> &'static str {
        match self {
            Self::NotInWorkspace { .. } => "NOT_IN_WORKSPACE",
            Self::NotAJjRepo => "NOT_A_JJ_REPO",
            Self::WorkspaceNotFound { .. } => "WORKSPACE_NOT_FOUND",
            Self::CommitFailed { .. } => "COMMIT_FAILED",
            Self::MergeConflict { .. } => "MERGE_CONFLICT",
            Self::MergeFailed { .. } => "MERGE_FAILED",
            Self::CleanupFailed { .. } => "CLEANUP_FAILED",
            Self::BeadUpdateFailed { .. } => "BEAD_UPDATE_FAILED",
            Self::JjCommandFailed { .. } => "JJ_COMMAND_FAILED",
            Self::InvalidState { .. } => "INVALID_STATE",
        }
    }

    #[allow(dead_code)]
    pub const fn is_recoverable(&self) -> bool {
        matches!(self, Self::MergeConflict { .. })
    }

    #[allow(dead_code)] // Public API method, tested but not used internally
    pub const fn phase(&self) -> DonePhase {
        match self {
            Self::NotInWorkspace { .. } | Self::NotAJjRepo | Self::WorkspaceNotFound { .. } => {
                DonePhase::ValidatingLocation
            }
            Self::CommitFailed { .. } => DonePhase::CommittingChanges,
            Self::MergeConflict { .. }
            | Self::MergeFailed { .. }
            | Self::CleanupFailed { .. }
            | Self::BeadUpdateFailed { .. }
            | Self::JjCommandFailed { .. }
            | Self::InvalidState { .. } => DonePhase::MergingToMain,
        }
    }
}

/// Phase of the done operation where an error occurred
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum DonePhase {
    /// Initial validation phase (checking workspace location)
    ValidatingLocation,
    /// Commit phase (committing uncommitted changes)
    CommittingChanges,
    /// Merge and cleanup phase (merging to main, cleanup, bead update)
    MergingToMain,
}

impl DonePhase {
    /// Returns the `snake_case` name of this phase
    #[must_use]
    #[allow(dead_code)]
    pub const fn name(&self) -> &'static str {
        match self {
            Self::ValidatingLocation => "validating_location",
            Self::CommittingChanges => "committing_changes",
            Self::MergingToMain => "merging_to_main",
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_done_args_to_options() {
        let args = DoneArgs {
            workspace: Some("test-ws".to_string()),
            message: Some("test commit".to_string()),
            keep_workspace: true,
            no_keep: false,
            squash: false,
            dry_run: false,
            detect_conflicts: false,
            no_bead_update: false,
            format: OutputFormat::Json,
        };

        let opts = args.to_options();

        assert_eq!(opts.workspace, Some("test-ws".to_string()));
        assert_eq!(opts.message, Some("test commit".to_string()));
        assert!(opts.keep_workspace);
        assert!(!opts.no_keep);
        assert!(!opts.squash);
        assert!(!opts.dry_run);
        assert!(matches!(opts.format, OutputFormat::Json));
    }

    #[test]
    fn test_done_phase_names() {
        assert_eq!(DonePhase::ValidatingLocation.name(), "validating_location");
        assert_eq!(DonePhase::CommittingChanges.name(), "committing_changes");
        assert_eq!(DonePhase::MergingToMain.name(), "merging_to_main");
    }

    #[test]
    fn test_done_error_codes() {
        let err = DoneError::NotInWorkspace {
            current_location: "main".to_string(),
        };
        assert_eq!(err.error_code(), "NOT_IN_WORKSPACE");
        assert_eq!(err.phase(), DonePhase::ValidatingLocation);

        // Test WorkspaceNotFound for API completeness
        let err2 = DoneError::WorkspaceNotFound {
            workspace_name: "test-ws".to_string(),
        };
        assert_eq!(err2.error_code(), "WORKSPACE_NOT_FOUND");
        assert_eq!(err2.phase(), DonePhase::ValidatingLocation);
    }

    #[test]
    fn test_merge_conflict_is_recoverable() {
        let err = DoneError::MergeConflict {
            conflicts: vec!["file.txt".to_string()],
        };
        assert!(err.is_recoverable());

        let err2 = DoneError::CommitFailed {
            reason: "test".to_string(),
        };
        assert!(!err2.is_recoverable());
    }

    #[test]
    fn test_done_output_serialization() {
        let output = DoneOutput {
            workspace_name: "test-ws".to_string(),
            bead_id: Some("zjj-test".to_string()),
            files_committed: 2,
            commits_merged: 1,
            merged: true,
            cleaned: true,
            bead_closed: true,
            session_updated: true,
            new_status: Some("completed".to_string()),
            pushed_to_remote: false,
            dry_run: false,
            preview: None,
            error: None,
        };

        assert_eq!(output.workspace_name, "test-ws");
        assert!(output.merged);
        assert!(output.cleaned);
    }

    #[test]
    fn test_done_display_formats() {
        let preview = DonePreview {
            uncommitted_files: vec!["file.txt".to_string()],
            commits_to_merge: vec![CommitInfo {
                change_id: "abc123".to_string(),
                commit_id: "xyz789".to_string(),
                description: "test commit".to_string(),
                timestamp: "2025-01-26T00:00:00Z".to_string(),
            }],
            potential_conflicts: vec![],
            bead_to_close: Some("zjj-test".to_string()),
            workspace_path: "/path/to/workspace".to_string(),
            conflict_detection: None,
        };

        // Verify preview field values
        assert_eq!(preview.uncommitted_files.len(), 1);
        assert_eq!(preview.uncommitted_files[0], "file.txt");
        assert_eq!(preview.bead_to_close, Some("zjj-test".to_string()));
        assert_eq!(preview.commits_to_merge.len(), 1);
        assert_eq!(preview.commits_to_merge[0].change_id, "abc123");
    }
}
